import './App.css';
import CadastroUser from './componentes/cadastroUser';
import State from './componentes/state';

function App() {
  return (
    <div className="conatiner">
      <header className="App-header">
        <h1>Hello world</h1>
      </header>
      <main>
        <State/>
      </main>
    </div>
  );
}

export default App;
