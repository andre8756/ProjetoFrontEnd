function Botao({label}) {
    return(
        <button>{label}</button>
    )
}

export default Botao